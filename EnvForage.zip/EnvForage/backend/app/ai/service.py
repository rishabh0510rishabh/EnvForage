"""AI Troubleshoot Service — orchestrates the full troubleshooting pipeline.

Pipeline:
    1. Build structured prompt from diagnostic context
    2. Call LLM provider for analysis
    3. Validate AI output through SafetyFilter
    4. Persist session + suggestions to DB for audit
    5. Return structured TroubleshootResponse
"""

import hashlib
import logging
import platform
import time
import uuid
from collections.abc import AsyncIterator
from datetime import datetime

import torch
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.ai.models import (
    DeviceType,
    TroubleshootRequest,
    TroubleshootResponse,
)
from app.ai.prompts.system import TROUBLESHOOT_SYSTEM_PROMPT
from app.ai.prompts.troubleshoot import TroubleshootPromptBuilder
from app.ai.providers import get_provider
from app.ai.providers.base import LLMProviderError
from app.models.ai_session import AIAuditLog, AISession, AISuggestion
from app.templates.safety import (
    SafetyViolationError,
    validate_rendered_output,
)

logger = logging.getLogger(__name__)


def get_device() -> str:
    """
    Detect the best available device for AI computations.
    """

    # Apple Silicon (MPS)
    if platform.system() == "Darwin" and platform.machine() == "arm64":
        if torch.backends.mps.is_available():
            return "mps"

    # CUDA
    if torch.cuda.is_available():
        return "cuda"

    # CPU fallback
    return "cpu"


class AITroubleshootService:
    """
    Orchestrates AI-assisted troubleshooting.
    """

    def __init__(self) -> None:
        self._prompt_builder = TroubleshootPromptBuilder()

    async def troubleshoot(
        self,
        request: TroubleshootRequest,
        db: AsyncSession,
    ) -> TroubleshootResponse:
        """
        Run the full AI troubleshooting pipeline.
        """

        session_id = str(uuid.uuid4())
        start_time = time.monotonic()
        input_hash = self._hash_input(request)

        # ── Step 1: Build prompt ──────────────────────────────────────────
        history = None

        if request.session_id:
            history = await self._fetch_session_history(
                db,
                request.session_id,
            )

        user_message = self._prompt_builder.build(
            request,
            history=history,
        )

        logger.info(
            "Troubleshoot prompt built (%d chars)",
            len(user_message),
        )

        # ── Step 2: Call LLM ──────────────────────────────────────────────
        device = get_device()

        logger.info("Selected device: %s", device)

        if device == DeviceType.MPS:
            logger.info(
                "Running with Apple Silicon (MPS) acceleration",
            )
        elif device == DeviceType.CUDA:
            logger.info("Running with CUDA acceleration")
        else:
            logger.info("Running with CPU fallback")

        provider = get_provider()
        provider_name = type(provider).__name__
        model_name = getattr(provider, "model", "unknown")

        try:
            llm_result = await provider.complete(
                system_prompt=TROUBLESHOOT_SYSTEM_PROMPT,
                user_message=user_message,
                response_model=TroubleshootResponse,
            )

        except LLMProviderError as exc:
            latency_ms = int(
                (time.monotonic() - start_time) * 1000
            )

            await self._log_audit(
                db=db,
                session_id=None,
                input_hash=input_hash,
                safety_passed=False,
                safety_violation=f"LLM error: {exc.reason}",
                provider=provider_name,
                tokens_used=0,
                latency_ms=latency_ms,
            )

            raise

        # ── Step 3: Safety filter ─────────────────────────────────────────
        safety_violation: str | None = None

        try:
            self._validate_response_safety(llm_result)

        except SafetyViolationError as exc:
            safety_violation = str(exc)

            latency_ms = int(
                (time.monotonic() - start_time) * 1000
            )

            await self._log_audit(
                db=db,
                session_id=None,
                input_hash=input_hash,
                safety_passed=False,
                safety_violation=safety_violation,
                provider=provider_name,
                tokens_used=0,
                latency_ms=latency_ms,
            )

            raise

        # ── Step 4: Enrich response ───────────────────────────────────────
        llm_result.session_id = session_id

        llm_result.repair_script_available = any(
            fix.repair_template_id is not None
            for fix in llm_result.suggested_fixes
        )

        # ── Step 5: Persist to DB ─────────────────────────────────────────
        latency_ms = int(
            (time.monotonic() - start_time) * 1000
        )

        token_usage = getattr(
            provider,
            "last_token_usage",
            None,
        )

        if callable(token_usage):
            token_usage = token_usage()

        elif not isinstance(token_usage, dict):
            token_usage = getattr(
                provider,
                "_last_usage",
                None,
            )

        total_tokens = (
            token_usage.get("total_tokens", 0)
            if token_usage
            else 0
        )

        await self._persist_session(
            db=db,
            session_id=session_id,
            request=request,
            response=llm_result,
            provider_name=provider_name,
            model_name=model_name,
        )

        await self._log_audit(
            db=db,
            session_id=session_id,
            input_hash=input_hash,
            safety_passed=True,
            safety_violation=None,
            provider=provider_name,
            tokens_used=total_tokens,
            latency_ms=latency_ms,
        )

        logger.info(
            "Troubleshoot complete: session=%s, fixes=%d, confidence=%.2f, latency=%dms",
            session_id,
            len(llm_result.suggested_fixes),
            llm_result.confidence,
            latency_ms,
        )

        return llm_result

    async def stream_troubleshoot(
        self,
        request: TroubleshootRequest,
        db: AsyncSession,
    ) -> AsyncIterator[str]:
        """
        Stream the AI troubleshooting response.
        """

        history = None

        if request.session_id:
            history = await self._fetch_session_history(
                db,
                request.session_id,
            )

        user_message = self._prompt_builder.build(
            request,
            history=history,
        )

        provider = get_provider()

        logger.info(
            "Starting troubleshoot stream (provider=%s)",
            type(provider).__name__,
        )

        async for chunk in provider.stream(
            system_prompt=TROUBLESHOOT_SYSTEM_PROMPT,
            user_message=user_message,
            response_model=TroubleshootResponse,
        ):
            yield chunk

    async def _fetch_session_history(
        self,
        db: AsyncSession,
        session_id: str,
    ) -> list[AISuggestion]:
        """
        Fetch previous AI suggestions.
        """

        try:
            stmt = (
                select(AISuggestion)
                .where(
                    AISuggestion.session_id
                    == uuid.UUID(session_id)
                )
                .order_by(
                    AISuggestion.step_number.asc()
                )
            )

            result = await db.execute(stmt)

            return list(result.scalars().all())

        except Exception as exc:
            logger.error(
                "Failed to fetch session history for %s: %s",
                session_id,
                exc,
            )

            return []

    def _hash_input(
        self,
        request: TroubleshootRequest,
    ) -> str:
        """
        Create SHA-256 hash of input.
        """

        raw = request.model_dump_json()

        return hashlib.sha256(
            raw.encode()
        ).hexdigest()[:64]

    def _validate_response_safety(
        self,
        response: TroubleshootResponse,
    ) -> None:
        """
        Validate all response text fields.
        """

        validate_rendered_output(
            response.root_cause,
            "ai_root_cause",
        )

        for fix in response.suggested_fixes:
            validate_rendered_output(
                fix.title,
                "ai_fix_title",
            )

            validate_rendered_output(
                fix.description,
                "ai_fix_description",
            )

            for cmd in fix.safe_commands:
                validate_rendered_output(
                    cmd,
                    "ai_safe_command",
                )

    async def _persist_session(
        self,
        db: AsyncSession,
        session_id: str,
        request: TroubleshootRequest,
        response: TroubleshootResponse,
        provider_name: str,
        model_name: str,
    ) -> None:
        """
        Persist AI session and suggestions.
        """

        try:
            db_session = AISession(
                id=uuid.UUID(session_id),
                provider=provider_name,
                model=model_name,
                created_at=datetime.utcnow(),
            )

            db.add(db_session)

            await db.flush()

            for fix in response.suggested_fixes:
                db_suggestion = AISuggestion(
                    id=uuid.uuid4(),
                    session_id=db_session.id,
                    step_number=fix.step,
                    title=fix.title,
                    description=fix.description,
                    severity=fix.severity,
                    safe_commands=(
                        fix.safe_commands
                        if fix.safe_commands
                        else None
                    ),
                    template_id=fix.repair_template_id,
                    created_at=datetime.utcnow(),
                )

                db.add(db_suggestion)

        except Exception as exc:
            logger.error(
                "Failed to persist AI session: %s",
                exc,
            )

    async def _log_audit(
        self,
        db: AsyncSession,
        *,
        session_id: str | None,
        input_hash: str,
        safety_passed: bool,
        safety_violation: str | None,
        provider: str,
        tokens_used: int,
        latency_ms: int,
    ) -> None:
        """
        Write audit log entry.
        """

        try:
            log = AIAuditLog(
                id=uuid.uuid4(),
                session_id=(
                    uuid.UUID(session_id)
                    if session_id
                    else None
                ),
                input_hash=input_hash,
                safety_passed=safety_passed,
                safety_violation=safety_violation,
                provider=provider,
                tokens_used=tokens_used,
                latency_ms=latency_ms,
                created_at=datetime.utcnow(),
            )

            db.add(log)

        except Exception as exc:
            logger.error(
                "Failed to write audit log: %s",
                exc,
            )
